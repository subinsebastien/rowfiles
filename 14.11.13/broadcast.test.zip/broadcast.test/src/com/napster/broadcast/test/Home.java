package com.napster.broadcast.test;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;


public class Home extends Activity implements OnClickListener {

	private ActivityReceiver mReceiver;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);
		
		mReceiver = new ActivityReceiver();
		
		findViewById(R.id.btn_app_broadcast).setOnClickListener(this);
		findViewById(R.id.btn_activity_broadcast).setOnClickListener(this);
	}

	@Override
	protected void onResume() {
		IntentFilter filter = new IntentFilter();
		filter.addAction("ACTION_HELLO_ACTIVITY");
		registerReceiver(mReceiver, filter);
		super.onResume();
	}
	
	@Override
	protected void onPause() {
		unregisterReceiver(mReceiver);
		super.onPause();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_app_broadcast:
			Intent appIntent = new Intent();
			appIntent.setAction("ACTION_HELLO_APPLICATION");
			sendBroadcast(appIntent);
			break;
			
		case R.id.btn_activity_broadcast:
			Intent actIntent = new Intent();
			actIntent.setAction("ACTION_HELLO_ACTIVITY");
			sendBroadcast(actIntent);
			break;
		}
	}

}

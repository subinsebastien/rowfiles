package com.napster.broadcast.test;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class ApplicationReceiver extends BroadcastReceiver {

	private String TAG = getClass().toString();
	
	@Override
	public void onReceive(Context context, Intent intent) {
		Log.e(TAG, "Broadcast Receiver By : ApplicationReceiver");
	}
}

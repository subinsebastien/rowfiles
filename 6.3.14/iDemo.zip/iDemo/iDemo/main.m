//
//  main.m
//  iDemo
//
//  Created by Subin Sebastian on 06/03/14.
//  Copyright (c) 2014 Subin Sebastian. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

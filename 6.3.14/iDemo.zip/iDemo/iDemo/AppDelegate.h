//
//  AppDelegate.h
//  iDemo
//
//  Created by Subin Sebastian on 06/03/14.
//  Copyright (c) 2014 Subin Sebastian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

//
//  ViewController.m
//  iDemo
//
//  Created by Subin Sebastian on 06/03/14.
//  Copyright (c) 2014 Subin Sebastian. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UITextField *num_one;
@property (weak, nonatomic) IBOutlet UITextField *num_two;
@property (weak, nonatomic) IBOutlet UILabel *result_label;

@end

@implementation ViewController

- (NSInteger) performOperation:(NSInteger) operation {
    NSInteger first_number = [[[self num_one] text] intValue];
    NSInteger second_number = [[[self num_two] text] intValue];
    NSInteger result = 0;
    switch (operation) {
        case 1:
            result = first_number + second_number;
            break;
        case 2:
            result = first_number - second_number;
            break;
        case 3:
            result = first_number * second_number;
            break;
        case 4:
            result = first_number / second_number;
            break;
        default:
            break;
    }
    
    return result;
}

- (IBAction)addNumbers:(id)sender {
    NSInteger result = [self performOperation:1];
    [[self result_label] setText:[NSString stringWithFormat:@"Addition Result : %i", result]];
}

- (IBAction)subtractNumbers:(id)sender {
    NSInteger result = [self performOperation:2];
    [[self result_label] setText:[NSString stringWithFormat:@"Subtraction Result : %i", result]];
}

- (IBAction)multiplyNumbers:(id)sender {
    NSInteger result = [self performOperation:3];
    [[self result_label] setText:[NSString stringWithFormat:@"Multiplication Result :  %i", result]];
}

- (IBAction)divideNumbers:(id)sender {
    NSInteger result = [self performOperation:4];
    [[self result_label] setText:[NSString stringWithFormat:@"Division Result : %i", result]];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

package com.napster.experiment.popup;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        PopupItem item1 = new PopupItem(0, "RUN ACTIVITY ONE", ActivityOne.class);
        PopupItem item2 = new PopupItem(1, "RUN ACTIVITY TWO", ActivityTwo.class);
        PopupItem item3 = new PopupItem(2, "RUN ACTIVITY THREE", ActivityThree.class);
        
        final Popup ourNicePopup = new Popup(this);
        
        ourNicePopup.addItem(item1);
        ourNicePopup.addItem(item2);
        ourNicePopup.addItem(item3);
        
        /*
         * Finally set an operation to be executed when one of the
         * popup item is choosen. In my case, it is nothing but starting
         * an activity. By the way, it is perfectly fine to pass the item
         * itself here and use its get*() methods to get the class and
         * item id or even the title string.
         */
        ourNicePopup.setOnItemClickListener(new OnPopupItemClickListener() {
			@Override
			public void onItemClick(Class<?> activityClass, int itemId) {
				startActivity(new Intent(MainActivity.this, activityClass));
			}
		});
        
        findViewById(R.id.btn).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				ourNicePopup.show(v);
			}
		});
    }
}
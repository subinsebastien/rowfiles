package com.napster.experiment.popup;

public interface OnPopupItemClickListener {
	public abstract void onItemClick(Class<?> activityClass, int itemId);
}

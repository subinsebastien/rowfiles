package com.napster.experiment.popup;

public class PopupItem {
	private int itemId;
	private String titleText;
	private Class<?> activityClass;
	
	public PopupItem(int itemId, String titleText, Class<?> activityClass) {
		super();
		this.itemId = itemId;
		this.titleText = titleText;
		this.activityClass = activityClass;
	}

	public int getItemId() {
		return itemId;
	}

	public String getTitleText() {
		return titleText;
	}

	public Class<?> getActivityClass() {
		return activityClass;
	}
}

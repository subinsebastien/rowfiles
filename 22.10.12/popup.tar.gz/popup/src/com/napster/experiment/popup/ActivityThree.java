package com.napster.experiment.popup;

import android.app.Activity;
import android.os.Bundle;

public class ActivityThree extends Activity {

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	
	    // TODO Auto-generated method stub
	}

}
